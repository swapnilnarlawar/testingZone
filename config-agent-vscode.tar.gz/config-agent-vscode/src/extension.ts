import * as vscode from 'vscode';
import { handleChat, setExtensionUri } from './participant';

/**
 * Extension entry point. Called by VSCode when the extension activates.
 *
 * Activation is triggered automatically when the user invokes @config-agent
 * in Copilot Chat (declared in package.json contributes.chatParticipants).
 */
export function activate(context: vscode.ExtensionContext): void {
  // Stash the extension URI so the participant can locate prompts/system.md
  setExtensionUri(context.extensionUri);

  const participant = vscode.chat.createChatParticipant(
    'config-generator-agent.config-agent',
    handleChat
  );

  // Icon shown next to @config-agent in the chat UI
  participant.iconPath = new vscode.ThemeIcon('settings-gear');

  // Follow-up suggestions after the agent responds
  participant.followupProvider = {
    provideFollowups(result, _context, _token) {
      const followups: vscode.ChatFollowup[] = [];
      const meta = result.metadata as { kind?: string } | undefined;

      if (meta?.kind === 'awaiting-paths') {
        followups.push({
          prompt: 'Use ./samples/platform-v2.4.1 and ./samples/existing-v2.3.0',
          label: 'Try with sample data',
          command: 'migrate',
        });
      }
      if (meta?.kind === 'done') {
        followups.push({
          prompt: 'Run migration for the next stage',
          label: 'Next stage',
          command: 'migrate',
        });
      }
      return followups;
    },
  };

  context.subscriptions.push(participant);
}

export function deactivate(): void {
  // nothing to clean up — VSCode disposes registered participants automatically
}
