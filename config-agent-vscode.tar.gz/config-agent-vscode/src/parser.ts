/**
 * Shell Config Parser
 *
 * Extracts variable definitions from .sh config files. Designed to run
 * outside Claude's context — its structured output is what we pass to the
 * model, never the raw bash.
 */

export interface ShellVariable {
  name: string;
  value: string;
  comment: string;
}

const SHEBANG = /^#!(\/usr\/bin\/env\s+)?ba?sh/;
const QUOTED = /^(?:export\s+)?([A-Za-z_]\w*)=(['"])([^'"]*)\2(?:\s*#.*)?$/;
const UNQUOTED = /^(?:export\s+)?([A-Za-z_]\w*)=(.+?)(?:\s*#.*)?$/;

export function parseShell(content: string): ShellVariable[] {
  const variables: ShellVariable[] = [];
  const lines = content.split('\n');
  let pendingComments: string[] = [];

  for (const line of lines) {
    const trimmed = line.trim();

    if (!trimmed || SHEBANG.test(trimmed)) {
      if (!trimmed.startsWith('#')) pendingComments = [];
      continue;
    }

    if (trimmed.startsWith('#')) {
      const stripped = trimmed.replace(/^#+\s*/, '');
      if (stripped) pendingComments.push(stripped);
      continue;
    }

    const quotedMatch = trimmed.match(QUOTED);
    const unquotedMatch = !quotedMatch ? trimmed.match(UNQUOTED) : null;

    if (quotedMatch) {
      variables.push({
        name: quotedMatch[1],
        value: quotedMatch[3],
        comment: pendingComments.join(' ').trim(),
      });
    } else if (unquotedMatch) {
      const value = unquotedMatch[2].trim().replace(/\s+#.*$/, '');
      variables.push({
        name: unquotedMatch[1],
        value,
        comment: pendingComments.join(' ').trim(),
      });
    }

    pendingComments = [];
  }

  return variables;
}
