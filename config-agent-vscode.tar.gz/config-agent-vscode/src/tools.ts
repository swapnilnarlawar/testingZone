/**
 * Tool implementations for the Config Generator Agent.
 *
 * All tools work on local files via vscode.workspace.fs. Shell parsing and
 * diffing happen in-process — the model only sees structured variable data,
 * never raw bash. This keeps token usage low and makes Claude's job purely
 * semantic (understand changes, generate annotations) rather than syntactic.
 */

import * as vscode from 'vscode';
import * as path from 'path';
import { parseShell, ShellVariable } from './parser';
import { diffVariables, VariableDiff } from './differ';

// ─── Tool schema definitions ──────────────────────────────────
// These match Anthropic's tool spec; the VSCode LM API uses the same shape.

export const tools: vscode.LanguageModelChatTool[] = [
  {
    name: 'discover_files',
    description:
      'List .sh files in a workspace directory (recursive, max depth 3). Use this FIRST to verify the directory exists and find which config files are present. Returns paths only — no file contents. Very token-efficient.',
    inputSchema: {
      type: 'object',
      properties: {
        directory: {
          type: 'string',
          description: 'Workspace-relative path, e.g. "platform-v2.4.1/meg2-configs/env/dev"',
        },
      },
      required: ['directory'],
    },
  },
  {
    name: 'parse_config',
    description:
      'Read a single .sh file and return its variable definitions (name, value, comment) as structured data — NOT raw file content. Use for new tenants when you need all variables from a file.',
    inputSchema: {
      type: 'object',
      properties: {
        file_path: {
          type: 'string',
          description: 'Workspace-relative path to a .sh file',
        },
      },
      required: ['file_path'],
    },
  },
  {
    name: 'diff_configs',
    description:
      'Compare two .sh files and return ONLY the delta (added/changed/removed/unchanged variable sets). Token-efficient — Claude never sees unchanged variables. PREFER this for existing tenants.',
    inputSchema: {
      type: 'object',
      properties: {
        existing_file: {
          type: 'string',
          description: 'Path to the tenant\'s currently deployed file',
        },
        new_file: {
          type: 'string',
          description: 'Path to the new platform tag file',
        },
      },
      required: ['existing_file', 'new_file'],
    },
  },
  {
    name: 'write_output',
    description:
      'Write an annotated .sh file to the workspace output directory. Call once per file at the end, before complete_analysis.',
    inputSchema: {
      type: 'object',
      properties: {
        file_name: {
          type: 'string',
          description: 'Just the filename, e.g. "Tenant.sh" — not a path',
        },
        content: {
          type: 'string',
          description:
            'Complete annotated .sh content. New vars: prepend "# [NEW - ACTION REQUIRED]" comment. Changed: "# [CHANGED - was: <oldValue>]". Placeholders: "# [FILL IN REQUIRED]".',
        },
      },
      required: ['file_name', 'content'],
    },
  },
  {
    name: 'complete_analysis',
    description:
      'Signal that all files have been written and the analysis is complete. YOU MUST call this last. Include a brief summary and any recommendations.',
    inputSchema: {
      type: 'object',
      properties: {
        new_count: { type: 'number' },
        changed_count: { type: 'number' },
        unchanged_count: { type: 'number' },
        removed_count: { type: 'number' },
        files_written: {
          type: 'array',
          items: { type: 'string' },
          description: 'List of filenames written via write_output',
        },
        recommendations: {
          type: 'array',
          items: { type: 'string' },
          description: 'Optional notes for the tenant (e.g. "Set DB_PASSWORD before deploying")',
        },
      },
      required: ['new_count', 'changed_count', 'unchanged_count', 'removed_count', 'files_written'],
    },
  },
];

// ─── Agent state (per-session) ────────────────────────────────
// Set fresh at the start of each chat request.

interface AgentState {
  workspaceFolder: vscode.WorkspaceFolder;
  outputDir: string;
  done: boolean;
  result: CompleteAnalysisInput | null;
  filesWritten: string[];
}

let state: AgentState | null = null;

export function resetAgentState(workspaceFolder: vscode.WorkspaceFolder, outputDir: string): void {
  state = { workspaceFolder, outputDir, done: false, result: null, filesWritten: [] };
}

export function getAgentState(): AgentState {
  if (!state) throw new Error('Agent state not initialised — call resetAgentState() first');
  return state;
}

// ─── Tool result types (for type safety in participant.ts) ────

interface CompleteAnalysisInput {
  new_count: number;
  changed_count: number;
  unchanged_count: number;
  removed_count: number;
  files_written: string[];
  recommendations?: string[];
}

// ─── Tool router ──────────────────────────────────────────────

export async function executeTool(
  name: string,
  input: Record<string, unknown>
): Promise<{ result: unknown; summary: string }> {
  const s = getAgentState();

  switch (name) {
    case 'discover_files':
      return discoverFiles(s, input.directory as string);
    case 'parse_config':
      return parseConfig(s, input.file_path as string);
    case 'diff_configs':
      return diffConfigs(s, input.existing_file as string, input.new_file as string);
    case 'write_output':
      return writeOutput(s, input.file_name as string, input.content as string);
    case 'complete_analysis':
      s.done = true;
      s.result = input as unknown as CompleteAnalysisInput;
      return {
        result: { success: true },
        summary: `✓ Analysis complete — ${input.new_count} new, ${input.changed_count} changed, ${input.unchanged_count} unchanged, ${input.removed_count} removed`,
      };
    default:
      return { result: { error: `Unknown tool: ${name}` }, summary: `Unknown tool: ${name}` };
  }
}

// ─── Tool implementations ─────────────────────────────────────

async function discoverFiles(s: AgentState, directory: string) {
  const dirUri = vscode.Uri.joinPath(s.workspaceFolder.uri, directory);
  try {
    const entries = await vscode.workspace.fs.readDirectory(dirUri);
    const files: string[] = [];
    const directories: string[] = [];

    for (const [name, type] of entries) {
      if (type === vscode.FileType.Directory) {
        directories.push(name);
        // Look one level deeper for .sh files (handles meg2-configs/env/STAGE pattern)
        try {
          const subUri = vscode.Uri.joinPath(dirUri, name);
          const subEntries = await vscode.workspace.fs.readDirectory(subUri);
          for (const [subName, subType] of subEntries) {
            if (subType === vscode.FileType.File && subName.endsWith('.sh')) {
              files.push(`${directory}/${name}/${subName}`);
            }
          }
        } catch {
          // ignore unreadable subdirs
        }
      } else if (type === vscode.FileType.File && name.endsWith('.sh')) {
        files.push(`${directory}/${name}`);
      }
    }

    return {
      result: { directory, directories, sh_files: files },
      summary: `Found ${files.length} .sh file${files.length !== 1 ? 's' : ''} in ${directory}` +
        (directories.length ? ` (subdirs: ${directories.join(', ')})` : ''),
    };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    return { result: { error: `Cannot read ${directory}: ${msg}` }, summary: `Error: ${msg}` };
  }
}

async function parseConfig(s: AgentState, filePath: string) {
  const uri = vscode.Uri.joinPath(s.workspaceFolder.uri, filePath);
  try {
    const bytes = await vscode.workspace.fs.readFile(uri);
    const content = new TextDecoder('utf-8').decode(bytes);
    const variables = parseShell(content);
    return {
      result: { file: filePath, variable_count: variables.length, variables },
      summary: `Parsed ${filePath.split('/').pop()} → ${variables.length} variable${variables.length !== 1 ? 's' : ''}`,
    };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    return { result: { error: `Cannot read ${filePath}: ${msg}` }, summary: `Error: ${msg}` };
  }
}

async function diffConfigs(s: AgentState, existingFile: string, newFile: string) {
  const oldUri = vscode.Uri.joinPath(s.workspaceFolder.uri, existingFile);
  const newUri = vscode.Uri.joinPath(s.workspaceFolder.uri, newFile);

  let oldVars: ShellVariable[] = [];
  try {
    const bytes = await vscode.workspace.fs.readFile(oldUri);
    oldVars = parseShell(new TextDecoder('utf-8').decode(bytes));
  } catch {
    // Missing existing file is OK — treat as all-new for this file
  }

  try {
    const bytes = await vscode.workspace.fs.readFile(newUri);
    const newVars = parseShell(new TextDecoder('utf-8').decode(bytes));
    const diff: VariableDiff = diffVariables(oldVars, newVars);
    const fname = newFile.split('/').pop();
    return {
      result: { existing_file: existingFile, new_file: newFile, ...diff },
      summary: `${fname}: +${diff.added.length} new  ~${diff.changed.length} changed  −${diff.removed.length} removed  =${diff.unchanged.length} unchanged`,
    };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    return { result: { error: `Cannot read new file ${newFile}: ${msg}` }, summary: `Error: ${msg}` };
  }
}

async function writeOutput(s: AgentState, fileName: string, content: string) {
  // Reject anything that looks like a path — fileName must be flat
  if (fileName.includes('/') || fileName.includes('\\') || fileName.includes('..')) {
    return {
      result: { error: 'file_name must be a flat filename, not a path' },
      summary: `Rejected unsafe path: ${fileName}`,
    };
  }

  const outUri = vscode.Uri.joinPath(s.workspaceFolder.uri, s.outputDir, fileName);
  try {
    // Ensure output dir exists
    const dirUri = vscode.Uri.joinPath(s.workspaceFolder.uri, s.outputDir);
    try {
      await vscode.workspace.fs.createDirectory(dirUri);
    } catch {
      // already exists
    }

    const bytes = new TextEncoder().encode(content);
    await vscode.workspace.fs.writeFile(outUri, bytes);
    s.filesWritten.push(fileName);
    return {
      result: { written: path.join(s.outputDir, fileName), bytes: bytes.length },
      summary: `Wrote ${fileName} (${bytes.length} bytes)`,
    };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    return { result: { error: `Failed to write ${fileName}: ${msg}` }, summary: `Error: ${msg}` };
  }
}
