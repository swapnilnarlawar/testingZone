/**
 * Chat participant handler — the agent loop.
 *
 * Runs when the user invokes @config-agent in Copilot Chat. Uses VSCode's
 * Language Model API to talk to Copilot's Claude (whatever model the user has
 * configured), with tool calls handled in-process against local files.
 */

import * as vscode from 'vscode';
import { tools, executeTool, resetAgentState, getAgentState } from './tools';
import { loadSystemPrompt, PromptContext } from './prompts';

interface ChatResult extends vscode.ChatResult {
  metadata: { kind: string };
}

export async function handleChat(
  request: vscode.ChatRequest,
  _context: vscode.ChatContext,
  stream: vscode.ChatResponseStream,
  token: vscode.CancellationToken
): Promise<ChatResult> {
  // ─── Handle /help command early ───
  if (request.command === 'help') {
    showHelp(stream);
    return { metadata: { kind: 'help' } };
  }

  // ─── Resolve workspace folder ───
  const wsFolder = vscode.workspace.workspaceFolders?.[0];
  if (!wsFolder) {
    stream.markdown('⚠ Please open a workspace folder first — the agent needs somewhere to read configs from and write output to.');
    return { metadata: { kind: 'error' } };
  }

  // ─── Resolve tenant type from /command or prompt content ───
  const tenantType = inferTenantType(request);

  // ─── Pick a language model ───
  // Prefer the configured family, fall back to first available Copilot model.
  const config = vscode.workspace.getConfiguration('configAgent');
  const preferredFamily = config.get<string>('modelFamily') || 'claude-3.5-sonnet';
  const maxTurns = config.get<number>('maxTurns') ?? 10;
  const outputDir = config.get<string>('outputDir') || 'generated';

  let model: vscode.LanguageModelChat | undefined;
  try {
    const matches = await vscode.lm.selectChatModels({ family: preferredFamily });
    model = matches[0];
    if (!model) {
      // Fall back to any vendor's Claude
      const claudeMatches = await vscode.lm.selectChatModels({ vendor: 'copilot' });
      model = claudeMatches.find((m) => m.family.toLowerCase().includes('claude')) || claudeMatches[0];
    }
  } catch (e) {
    stream.markdown(`⚠ Failed to select a language model: ${(e as Error).message}`);
    return { metadata: { kind: 'error' } };
  }

  if (!model) {
    stream.markdown(
      '⚠ No language model available. Ensure GitHub Copilot is installed and you have Claude (or another supported model) enabled.\n\n' +
        'Try: command palette → "GitHub Copilot: Manage Chat Models".'
    );
    return { metadata: { kind: 'error' } };
  }

  stream.markdown(`Using **${model.name}** (\`${model.family}\`)\n\n`);

  // ─── Initialise agent state ───
  resetAgentState(wsFolder, outputDir);

  // ─── Build the conversation ───
  const promptCtx: PromptContext = {
    tenantType,
    workspaceName: wsFolder.name,
    outputDir,
  };

  const systemPrompt = await loadSystemPrompt(getExtensionUri(), promptCtx);
  const userTurn = request.prompt.trim() ||
    (tenantType === 'new'
      ? 'Set up a new tenant from a platform release tag in this workspace.'
      : 'Migrate this tenant from their current config to a new platform release tag.');

  const messages: vscode.LanguageModelChatMessage[] = [
    vscode.LanguageModelChatMessage.User(`${systemPrompt}\n\n---\n\nUser request: ${userTurn}`),
  ];

  // ─── Agent loop ───
  let turn = 0;
  let totalInputTokens = 0;
  let totalOutputTokens = 0;

  while (turn < maxTurns) {
    turn++;
    if (token.isCancellationRequested) {
      stream.markdown('\n\n⚠ Cancelled by user.');
      return { metadata: { kind: 'cancelled' } };
    }

    let response: vscode.LanguageModelChatResponse;
    try {
      response = await model.sendRequest(messages, { tools }, token);
    } catch (e) {
      const err = e as Error;
      stream.markdown(`\n\n⚠ Model error on turn ${turn}: ${err.message}`);
      return { metadata: { kind: 'error' } };
    }

    // Stream parts to the user as they arrive
    const toolCalls: vscode.LanguageModelToolCallPart[] = [];
    const assistantParts: (vscode.LanguageModelTextPart | vscode.LanguageModelToolCallPart)[] = [];

    try {
      for await (const part of response.stream) {
        if (part instanceof vscode.LanguageModelTextPart) {
          stream.markdown(part.value);
          assistantParts.push(part);
        } else if (part instanceof vscode.LanguageModelToolCallPart) {
          toolCalls.push(part);
          assistantParts.push(part);
        }
      }
    } catch (e) {
      const err = e as Error;
      stream.markdown(`\n\n⚠ Stream error on turn ${turn}: ${err.message}`);
      return { metadata: { kind: 'error' } };
    }

    // No tool calls → model is done speaking
    if (toolCalls.length === 0) {
      const state = getAgentState();
      if (!state.done) {
        stream.markdown('\n\n⚠ Agent ended without calling `complete_analysis`. Output may be incomplete.');
        return { metadata: { kind: 'incomplete' } };
      }
      break;
    }

    // Record the assistant's turn (text + tool calls)
    messages.push(vscode.LanguageModelChatMessage.Assistant(assistantParts));

    // Execute tools and collect results
    const toolResultParts: vscode.LanguageModelToolResultPart[] = [];
    for (const call of toolCalls) {
      const inputObj = (call.input as Record<string, unknown>) || {};
      stream.progress(`Tool: ${call.name}(${summariseInput(call.name, inputObj)})`);

      const { result, summary } = await executeTool(call.name, inputObj);

      // Visible breadcrumb
      stream.markdown(`\n\n\`✓\` **${call.name}** — ${summary}`);

      toolResultParts.push(
        new vscode.LanguageModelToolResultPart(call.callId, [
          new vscode.LanguageModelTextPart(JSON.stringify(result)),
        ])
      );

      if (getAgentState().done) break;
    }

    // Feed tool results back to the model
    messages.push(vscode.LanguageModelChatMessage.User(toolResultParts));

    if (getAgentState().done) break;
  }

  // ─── Summarise and finish ───
  const state = getAgentState();
  if (state.done && state.result) {
    const r = state.result;
    stream.markdown(
      `\n\n---\n\n**Done in ${turn} turn${turn !== 1 ? 's' : ''}.** ` +
        `+${r.new_count} new, ~${r.changed_count} changed, =${r.unchanged_count} unchanged, −${r.removed_count} removed. ` +
        `Wrote ${r.files_written.length} file${r.files_written.length !== 1 ? 's' : ''} to \`${outputDir}/\`.\n\n`
    );

    if (r.recommendations?.length) {
      stream.markdown('### Recommendations\n\n');
      for (const rec of r.recommendations) {
        stream.markdown(`- ${rec}\n`);
      }
    }

    // Offer to open the generated files
    for (const fname of state.filesWritten) {
      const fileUri = vscode.Uri.joinPath(wsFolder.uri, outputDir, fname);
      stream.anchor(fileUri, fname);
      stream.markdown('  ');
    }

    return { metadata: { kind: 'done' } };
  }

  stream.markdown(`\n\n⚠ Agent reached the ${maxTurns}-turn limit without finishing. Raise \`configAgent.maxTurns\` if your config has many files.`);
  return { metadata: { kind: 'incomplete' } };
}

// ─── Helpers ──────────────────────────────────────────────────

function inferTenantType(request: vscode.ChatRequest): 'new' | 'existing' {
  if (request.command === 'init') return 'new';
  if (request.command === 'migrate') return 'existing';
  // Heuristic on prompt content
  const p = request.prompt.toLowerCase();
  if (/\bnew\b|init|first[- ]time|fresh|set[- ]up/.test(p)) return 'new';
  return 'existing';
}

function summariseInput(name: string, input: Record<string, unknown>): string {
  switch (name) {
    case 'discover_files':
      return input.directory as string;
    case 'parse_config':
      return (input.file_path as string)?.split('/').pop() || '';
    case 'diff_configs': {
      const ex = (input.existing_file as string)?.split('/').pop() || '';
      const nw = (input.new_file as string)?.split('/').pop() || '';
      return `${ex} → ${nw}`;
    }
    case 'write_output':
      return input.file_name as string;
    case 'complete_analysis':
      return `${input.files_written ? (input.files_written as string[]).length : 0} files`;
    default:
      return '';
  }
}

function showHelp(stream: vscode.ChatResponseStream): void {
  stream.markdown(`### Config Generator Agent

Helps tenants migrate platform \`.sh\` configs between release versions.

**Commands**

- \`/migrate\` — compare your current config against a new platform tag (existing tenants)
- \`/init\` — set up a new tenant from a platform tag (new tenants)

**Examples**

\`\`\`
@config-agent /migrate
   I'll figure out paths from the workspace structure.

@config-agent /migrate from ./current-deploy to ./platform-v2.4.1 stage prod
   Explicit paths and stage.

@config-agent /init from ./platform-v2.4.1 stage dev
   New tenant — all variables surfaced for configuration.
\`\`\`

**How it works**

The agent uses tool calls to:
1. Discover \`.sh\` files in the directories you point it at
2. Parse them locally (no raw bash sent to the model)
3. Diff existing vs new (only the delta goes to Claude — ~80% token savings)
4. Write annotated output to \`./generated/\`

Output files include comments marking new variables (\`# [NEW - ACTION REQUIRED]\`),
changed variables (\`# [CHANGED - was: ...]\`), and placeholder values that need
filling in (\`# [FILL IN REQUIRED]\`).
`);
}

// HACK: store extension URI for prompt loading. Set in extension.ts activate().
let _extensionUri: vscode.Uri | undefined;
export function setExtensionUri(uri: vscode.Uri): void {
  _extensionUri = uri;
}
function getExtensionUri(): vscode.Uri {
  if (!_extensionUri) {
    throw new Error('Extension URI not set — call setExtensionUri() in activate()');
  }
  return _extensionUri;
}
