/**
 * Variable Differ
 *
 * Computes added/changed/removed/unchanged between two variable arrays.
 * The agent's diff_configs tool wraps parseShell + diffVariables and only
 * returns the delta to Claude — much more token-efficient than two full lists.
 */

import { ShellVariable } from './parser';

export interface ChangedVariable extends ShellVariable {
  oldValue: string;
}

export interface VariableDiff {
  added: ShellVariable[];
  removed: ShellVariable[];
  changed: ChangedVariable[];
  unchanged: ShellVariable[];
}

export function diffVariables(
  oldVars: ShellVariable[],
  newVars: ShellVariable[]
): VariableDiff {
  const oldMap = new Map(oldVars.map((v) => [v.name, v]));
  const newMap = new Map(newVars.map((v) => [v.name, v]));

  const added = newVars.filter((v) => !oldMap.has(v.name));
  const removed = oldVars.filter((v) => !newMap.has(v.name));

  const changed: ChangedVariable[] = newVars
    .filter((v) => oldMap.has(v.name) && oldMap.get(v.name)!.value !== v.value)
    .map((v) => ({ ...v, oldValue: oldMap.get(v.name)!.value }));

  const unchanged = newVars.filter(
    (v) => oldMap.has(v.name) && oldMap.get(v.name)!.value === v.value
  );

  return { added, removed, changed, unchanged };
}
