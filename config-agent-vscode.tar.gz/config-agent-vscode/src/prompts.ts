/**
 * Loads the system prompt from prompts/system.md and interpolates variables.
 * Keeps the prompt as plain Markdown so non-developers can tune the agent.
 */

import * as vscode from 'vscode';
import * as path from 'path';

export interface PromptContext {
  tenantType: 'new' | 'existing';
  workspaceName: string;
  newPath?: string;
  existingPath?: string;
  stage?: string;
  outputDir: string;
}

export async function loadSystemPrompt(
  extensionUri: vscode.Uri,
  ctx: PromptContext
): Promise<string> {
  const promptUri = vscode.Uri.joinPath(extensionUri, 'prompts', 'system.md');
  let template: string;

  try {
    const bytes = await vscode.workspace.fs.readFile(promptUri);
    template = new TextDecoder('utf-8').decode(bytes);
  } catch {
    // Fallback for packaged extensions if file isn't reachable
    template = FALLBACK_PROMPT;
  }

  return template
    .replace(/\{TENANT_TYPE_UPPER\}/g, ctx.tenantType.toUpperCase())
    .replace(/\{TENANT_TYPE_DESCRIPTION\}/g,
      ctx.tenantType === 'new'
        ? 'New (first deployment — all variables need configuring)'
        : 'Existing (upgrading — surface only new and changed variables)')
    .replace(/\{WORKSPACE_NAME\}/g, ctx.workspaceName)
    .replace(/\{NEW_PATH\}/g, ctx.newPath ?? '(to be determined)')
    .replace(/\{EXISTING_PATH\}/g, ctx.existingPath ?? 'N/A (new tenant)')
    .replace(/\{STAGE\}/g, ctx.stage ?? '(to be determined)')
    .replace(/\{OUTPUT_DIR\}/g, ctx.outputDir);
}

const FALLBACK_PROMPT = `You are a Config Generator Agent. Use the available tools to migrate .sh configs.
Tenant type: {TENANT_TYPE_UPPER}. Output to {OUTPUT_DIR}/. Call complete_analysis when done.`;
