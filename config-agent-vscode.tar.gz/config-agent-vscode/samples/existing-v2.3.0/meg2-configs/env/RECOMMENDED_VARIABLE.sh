#!/bin/bash
# RECOMMENDED_VARIABLE.sh — non-stage-specific recommended defaults

export RETRY_COUNT=3
export RETRY_DELAY_MS=1000
