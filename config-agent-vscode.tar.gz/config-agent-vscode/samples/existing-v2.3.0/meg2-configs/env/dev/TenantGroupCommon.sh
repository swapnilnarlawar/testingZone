#!/bin/bash
# TenantGroupCommon.sh — settings shared across all tenants in a group

# Group identification
export GROUP_NAME="acme-group"
export GROUP_TIER="enterprise"

# Default region
export DEFAULT_REGION="us-east-1"
