#!/bin/bash
# TenantGroupAdmin.sh — admin-level group settings

# Admin credentials
export ADMIN_EMAIL="admin@acme.com"
export ADMIN_GROUP_ID="acme-admins"

# Logging
export LOG_LEVEL="INFO"
export LOG_DESTINATION="/var/log/platform"

# Rate limiting
export RATE_LIMIT_REQUESTS_PER_MINUTE=1000
