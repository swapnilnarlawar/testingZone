#!/bin/bash
# Tenant.sh — tenant-specific configuration
# Platform version: v2.3.0

# Tenant identification
export TENANT_ID="acme-corp"
export TENANT_NAME="Acme Corporation"

# Database connection
export DB_HOST="postgres-v1.acme.internal"
export DB_PORT=5432
export DB_NAME="acme_prod"

# API endpoints
export API_BASE_URL="https://api.acme.com/v1"
export API_TIMEOUT_SECONDS=30

# Feature flags
export FEATURE_NEW_DASHBOARD=false
export FEATURE_BETA_REPORTING=true

# Resource limits
export MAX_CONCURRENT_JOBS=10
export MAX_REQUEST_SIZE_MB=50
