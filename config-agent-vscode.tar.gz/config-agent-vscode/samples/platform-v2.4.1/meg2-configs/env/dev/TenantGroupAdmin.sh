#!/bin/bash
# TenantGroupAdmin.sh — admin-level group settings

# Admin credentials
export ADMIN_EMAIL="<ADMIN_EMAIL>"
export ADMIN_GROUP_ID="<TENANT_ID>-admins"

# Logging
export LOG_LEVEL="INFO"
export LOG_DESTINATION="/var/log/platform"
# Retention added in v2.4 — set per your compliance policy
export LOG_RETENTION_DAYS=30

# Rate limiting
export RATE_LIMIT_REQUESTS_PER_MINUTE=1000

# Audit logging (new in v2.4)
export AUDIT_LOG_ENABLED=true
export AUDIT_LOG_DESTINATION="<YOUR_AUDIT_SINK_URL>"
