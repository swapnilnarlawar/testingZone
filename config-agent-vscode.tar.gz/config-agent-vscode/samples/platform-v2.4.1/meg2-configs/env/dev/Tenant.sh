#!/bin/bash
# Tenant.sh — tenant-specific configuration
# Platform version: v2.4.1

# Tenant identification
export TENANT_ID="<TENANT_ID>"
export TENANT_NAME="<TENANT_NAME>"

# Database connection
# DB_HOST format changed: now requires v2 cluster endpoint
export DB_HOST="<YOUR_DB_HOST>.postgres-v2.platform.io"
export DB_PORT=5432
export DB_NAME="<TENANT_ID>_prod"

# Read replica added in v2.4 — required for new dashboard feature
export DB_REPLICA_HOST="<YOUR_DB_REPLICA_HOST>.postgres-v2.platform.io"

# API endpoints
export API_BASE_URL="https://api.acme.com/v2"
export API_TIMEOUT_SECONDS=30

# Feature flags
export FEATURE_NEW_DASHBOARD=true
export FEATURE_BETA_REPORTING=true

# Resource limits
export MAX_CONCURRENT_JOBS=10
export MAX_REQUEST_SIZE_MB=100

# Observability (new in v2.4)
export OTEL_ENDPOINT="https://otel.platform.io:4317"
export OTEL_SERVICE_NAME="<TENANT_ID>-service"
