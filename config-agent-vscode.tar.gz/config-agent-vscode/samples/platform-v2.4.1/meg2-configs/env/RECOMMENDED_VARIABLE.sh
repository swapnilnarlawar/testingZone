#!/bin/bash
# RECOMMENDED_VARIABLE.sh — non-stage-specific recommended defaults

export RETRY_COUNT=5
export RETRY_DELAY_MS=1000
export RETRY_BACKOFF_MULTIPLIER=2

# Circuit breaker (new in v2.4)
export CIRCUIT_BREAKER_ENABLED=true
export CIRCUIT_BREAKER_THRESHOLD=5
