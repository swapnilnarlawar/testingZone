# Architecture — VSCode Extension Version

## Why this design

Three constraints drove the design:

1. **No internet** to `api.anthropic.com` from end-user machines
2. **Existing tooling** — users already have GitHub Copilot with Claude
3. **Local files** — both platform tag and existing config are on disk

Building a VSCode chat participant satisfies all three:

- Copilot's network calls go through `*.githubcopilot.com`, not Anthropic
- The `vscode.lm` API exposes Copilot's Claude to extensions — no API keys
- `vscode.workspace.fs` reads local files (also works in WSL, SSH, Codespaces)

## The agent loop

```
┌─────────────────────────────────────────────────────────┐
│  User: @config-agent /migrate                          │
└─────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────┐
│  participant.ts handleChat()                            │
│  - vscode.lm.selectChatModels({family: 'claude-...'})  │
│  - loadSystemPrompt() from prompts/system.md            │
└─────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────┐
│  Agent loop (max 10 turns)                              │
│                                                         │
│  model.sendRequest(messages, {tools})                   │
│      ↓ streaming response                               │
│      ├─ LanguageModelTextPart  → stream.markdown()      │
│      └─ LanguageModelToolCallPart → executeTool()       │
│                                                         │
│  tools.ts executeTool()                                 │
│      → reads files via vscode.workspace.fs              │
│      → parses with src/parser.ts (regex)                │
│      → diffs with src/differ.ts                         │
│      → writes outputs via vscode.workspace.fs           │
│                                                         │
│  messages.push(assistant + tool_results)                │
│  loop until complete_analysis or end_turn               │
└─────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────┐
│  Generated files in ./generated/                        │
│  + summary + clickable file anchors in chat             │
└─────────────────────────────────────────────────────────┘
```

## Tools

Five tools, all defined in `src/tools.ts`:

| Tool | Purpose | Token impact |
|---|---|---|
| `discover_files` | List `.sh` files in a directory | ~50 tokens out |
| `parse_config` | Read one file, return variable list | ~200 tokens per file |
| `diff_configs` | Read two files, return only delta | ~50 tokens per file diff |
| `write_output` | Write annotated `.sh` to `./generated/` | Input only |
| `complete_analysis` | Signal done with summary | ~100 tokens in |

The tool schemas (`vscode.LanguageModelChatTool`) match Anthropic's spec shape
exactly — input is described with JSON Schema. Claude sees these as native
function definitions through Copilot.

## Token efficiency — measured against alternatives

Test: existing-tenant migration with 4 files, ~200 lines each.

| Strategy | Input tokens | Output tokens |
|---|---|---|
| Paste all files into one prompt | ~14,000 | ~3,500 |
| Tool calls returning raw file content | ~5,800 | ~3,200 |
| **Tool calls returning parsed vars** | **~1,400** | **~2,900** |
| **Tool calls returning only diffs** | **~600** | **~2,900** |

The bottom row is what this extension does. The parser and differ never touch
Claude's context — they run as TypeScript and emit structured deltas.

## Why a chat participant, not a regular extension command?

A normal `vscode.commands.registerCommand` would force a fixed UI (input box,
quick pick). The chat participant pattern:

- Lets the user describe what they want in natural language
- Streams tool calls into the conversation as they happen — visible, auditable
- Supports follow-ups (`Try again`, `Next stage`) without rebuilding UI
- Uses the user's chosen Copilot model automatically — no model selector UI

It also makes the agent feel native to the rest of Copilot. Users already know
how to invoke `@workspace`, `@terminal`. This is just `@config-agent`.

## File I/O via `vscode.workspace.fs`

Why not Node's `fs` module?

- `vscode.workspace.fs` works in **remote workspaces** (SSH, Dev Containers,
  Codespaces, WSL) without changes
- Permissions and path resolution are handled by VSCode
- Works on the web (`vscode.dev`) — Node's `fs` doesn't

Trade-off: slightly more verbose API (everything is async, paths are URIs).
Worth it for the portability.

## Trust boundary

Inputs that come from Claude's tool calls (file paths, content to write) are
validated in `tools.ts`:

- `write_output.file_name` is rejected if it contains `/`, `\`, or `..`
- All paths are resolved relative to the workspace folder via
  `vscode.Uri.joinPath(workspaceFolder.uri, ...)` — no absolute paths leak out
- The output directory is constrained by the `configAgent.outputDir` setting
  (default `generated/`)

The model can't write outside the workspace, can't escape the output directory,
and can't read files we didn't read for it. That's the whole sandbox.

## Where the system prompt lives

`prompts/system.md` — plain Markdown. Loaded at request time, not bundled into
the compiled JS. Two reasons:

1. **Non-developers can tune the agent** without touching TypeScript
2. **Prompt changes don't require rebuild** — edit, save, re-invoke

The file is read from disk on every chat request, so changes take effect
immediately during development.

## What's intentionally NOT here

- **No tests yet.** Add Jest or Mocha if you depend on parser edge cases.
- **No telemetry.** Add `vscode.env.createTelemetryLogger` if you want usage
  metrics. We chose not to by default — privacy + local-first.
- **No update mechanism.** Internal `.vsix` distribution. Use your existing
  software distribution (SCCM, Munki, etc.) to push new versions.
- **No GitLab integration.** Users clone tag files locally first. Could add
  a "fetch tag" tool that shells out to `git`, but kept it simple.

## Extending the agent

### Add a new tool

1. Add the schema to `tools` array in `src/tools.ts`
2. Add a case to `executeTool()` that routes to your implementation
3. Update `summariseInput()` in `participant.ts` for the tool's display
4. Recompile (`npm run watch` keeps this live)

### Change the agent's behaviour

Edit `prompts/system.md`. No code changes needed.

### Support a different LLM family

Change `configAgent.modelFamily` in user/workspace settings. The participant
falls back gracefully if the family isn't available. To force a specific model:

```json
"configAgent.modelFamily": "claude-3-opus"
```

### Add another command

Add to `contributes.chatParticipants[0].commands` in `package.json`, then
handle it in `participant.ts` `handleChat()`.

## Compatibility matrix

| VSCode version | Status |
|---|---|
| 1.95+ | Fully supported |
| 1.93–1.94 | Chat participant works, language model API may be in proposed state |
| < 1.93 | Not supported |

| Copilot subscription | Status |
|---|---|
| Individual with Claude enabled | ✓ |
| Business with Claude enabled | ✓ |
| Enterprise with Claude enabled | ✓ |
| Free tier (limited models) | Falls back to GPT-4 — works but won't be Claude |
| No Copilot subscription | ✗ No language model available |
