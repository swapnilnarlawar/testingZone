# Config Generator Agent — VSCode Extension

A VSCode chat participant (`@config-agent`) that helps tenants migrate platform
`.sh` configuration files between release versions. Runs entirely locally — uses
**your existing GitHub Copilot's Claude model** through VSCode's Language Model
API. No API keys, no external services, no internet calls beyond what Copilot
already does.

## What it does

```
You: @config-agent migrate

@config-agent: I'll migrate your tenant config. Which type?
   → New tenant (first deployment)
   → Existing tenant (upgrade)

You: existing — old in ./current/, new in ./platform-v2.4.1/, stage dev

@config-agent: [analyses 4 files using tool calls]
   ✓ discover_files(./platform-v2.4.1)  → 4 stages found
   ✓ diff_configs(Tenant.sh)             → +3 new, ~1 changed
   ✓ diff_configs(TenantGroupAdmin.sh)   → +1 new
   ✓ diff_configs(TenantGroupCommon.sh)  → 0 changes, skipping
   ✓ diff_configs(RECOMMENDED_VARIABLE.sh) → +2 new
   ✓ write_output × 4 → ./generated/
   ✓ complete_analysis
   
   Migration ready in ./generated/. 6 new variables need values:
   • DB_REPLICA_HOST  (Tenant.sh)
   • LOG_RETENTION_DAYS  (TenantGroupAdmin.sh)
   ...
```

## Prerequisites

- **VSCode 1.95** or newer
- **GitHub Copilot** subscription with Claude available (Sonnet or Opus)
- **Node.js 20+** — only needed to build the extension the first time

## Setup

### Option A — Run from source (development mode)

```bash
git clone <this-repo>
cd config-agent-vscode
npm install
code .
# Press F5 → opens a new VSCode window with the extension loaded
```

In the new window, open any folder containing your `.sh` configs, then open
Copilot Chat (`Ctrl+Alt+I` / `Cmd+Ctrl+I`) and type `@config-agent`.

### Option B — Package as `.vsix` and install permanently

```bash
npm install -g @vscode/vsce
vsce package
# Produces config-generator-agent-0.1.0.vsix
code --install-extension config-generator-agent-0.1.0.vsix
```

For air-gapped distribution, copy the `.vsix` file and run the install command
on each user's machine.

## Usage

Once the extension is loaded, in any VSCode workspace with your config files:

```
@config-agent migrate
```

The agent will ask follow-up questions and run the analysis. Generated files
land in `./generated/` (or a path you specify).

### Available commands

| Command | What it does |
|---|---|
| `@config-agent migrate` | Compare existing config against new platform tag |
| `@config-agent init` | Set up a new tenant from a platform tag |
| `@config-agent /help` | Show available subcommands |

You can also just describe what you want in plain English — the agent will
figure out the right command.

## How it works

1. **You describe the task** in Copilot Chat
2. **The extension picks your Claude model** via `vscode.lm.selectChatModels()` —
   whatever Copilot is configured to use (Sonnet, Opus, etc.)
3. **The agent loop runs** with these tools:
   - `discover_files(path)` — list `.sh` files in a directory
   - `parse_config(path)` — extract variables from one file
   - `diff_configs(old, new)` — diff two files, return only the delta
   - `write_output(name, content)` — write annotated config to `./generated/`
   - `complete_analysis(summary)` — finish
4. **Shell parsing is local** — files never leave your machine, and Claude only
   sees structured variable data, not raw bash. Token-efficient by design.
5. **Output is written to your workspace** — open the generated files, review,
   commit.

## Repo structure

```
config-agent-vscode/
├── README.md
├── package.json                    ← extension manifest
├── tsconfig.json
├── .vscode/
│   ├── launch.json                 ← F5 launches dev host
│   ├── tasks.json                  ← build tasks
│   └── extensions.json             ← recommends TS extension
├── src/
│   ├── extension.ts                ← entry point
│   ├── participant.ts              ← @config-agent handler + agent loop
│   ├── tools.ts                    ← tool implementations (read/write files)
│   ├── parser.ts                   ← shell variable extractor
│   ├── differ.ts                   ← variable diff
│   └── prompts.ts                  ← loads system prompt
├── prompts/
│   └── system.md                   ← agent instructions (Markdown, editable)
├── samples/                        ← test data — try the agent on these
│   ├── platform-v2.4.1/
│   └── existing-v2.3.0/
└── docs/
    └── architecture.md             ← why this design
```

## Trying it out

The `samples/` folder has fake platform and existing configs you can run the
agent against before pointing it at real files:

```
@config-agent migrate from samples/existing-v2.3.0 to samples/platform-v2.4.1 stage dev
```

## Modifying the agent

Most users won't need to. But if you do:

- **Change the agent's behaviour** → edit `prompts/system.md`. Plain Markdown,
  no code changes needed.
- **Add a new tool** → edit `src/tools.ts`. Each tool is a regular async TS
  function.
- **Adjust the file structure assumptions** (currently `meg2-configs/env/STAGE/`)
  → edit `src/tools.ts` `discoverFiles()`.

Rebuild with `npm run compile` (or `npm run watch` for live rebuild during
development).

## Why this design

See `docs/architecture.md` for the full reasoning. Short version:

- **Local-first**: all file I/O via `vscode.workspace.fs`. Works on Windows,
  macOS, Linux, and remote workspaces (SSH, WSL, Codespaces).
- **No API key juggling**: uses Copilot's existing Claude access. If your team
  has Copilot, the agent works. No `ANTHROPIC_API_KEY` env var.
- **Token-efficient**: shell parsing happens in TypeScript, not Claude's context.
  Diffs return only the delta. Typical run: ~2–4k tokens.
- **Inspectable**: the agent's tool calls stream into Copilot Chat as you watch.
  No black box.

## License

Internal use. Replace this section with your company's standard header.
